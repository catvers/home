# CatVers Studio — official website

Independent software studio website for **CatVers Studio**, managed by
**Asis Kumar Singh**. Building useful digital products with AI and technology.

## Tech stack

- **Vite + React + TypeScript + React Router** (static build, no SSR)
- Custom CSS only — no Tailwind, no UI frameworks (`react`, `react-router-dom`
  are the only runtime dependencies)
- Content-driven: every product, project, and update renders from data files

## Run locally

```bash
npm install
npm run dev      # dev server with hot reload
```

## Build & deploy

```bash
npm run build     # type-checks, then outputs static files to dist/
npm run preview   # preview the production build locally
```

Deploy `dist/` to any static host (Netlify, Vercel, GitHub Pages, Cloudflare
Pages, …). **SPA rewrite required:** configure the host to serve `index.html`
for unknown paths so `/products/...`, `/about`, etc. resolve on refresh.
(Netlify: a `_redirects` file with `/* /index.html 200`. Vercel: `rewrites`
in `vercel.json`.)

Before launch, replace the placeholder domain `https://catvers.studio` in
`src/data/site.ts` (`site.url`) and `public/sitemap.xml` with the real domain.

## Adding a new product

Edit **`src/data/products.ts`** — copy an entry, change the fields, save.
That's it. The product automatically appears on:

- `/products` (search, category/status/platform filters)
- Home page featured section (if `featured: true`)
- Home page "Recently Published" (if `status: 'published'`)
- Home page "Currently Building" (if `status` is `in-development` or `coming-soon`)
- Its own page at `/products/<slug>`
- Related products on other product pages

Fields: `id`, `slug`, `name`, `shortDescription`, `longDescription`,
`category`, `platform`, `status` (`published` | `in-development` |
`coming-soon` | `experimental` | `archived`), `logo`, `coverImage`,
`screenshots`, `websiteUrl`, `downloadUrl`, `sourceUrl`, `launchDate`,
`lastUpdated`, `features`, `tags`, `featured`, `published`, `accent`.

Rules: leave `websiteUrl`/`downloadUrl` as `null` until a real link exists
(buttons hide automatically — never dead links). Leave `launchDate` empty
until announced. Set `published: false` to hide an entry completely. Never
invent user counts, revenue, awards, or team members.

Projects → `src/data/projects.ts`. Updates → `src/data/updates.ts` (newest
first). Studio info → `src/data/site.ts`.

## Admin dashboard

Open `/admin` in the browser (not linked from the nav). Add/edit/delete
products, projects, updates, and site info with live preview. **Local only:**
changes live in `localStorage`, not on a server — press **Export JSON** and
copy the data back into `src/data/*.ts` to publish. See
`src/admin/README.md` for the full architecture and backend-integration notes.

## Project structure

```
src/
  types.ts            # Product, Project, UpdateEntry, SiteInfo
  data/               # content: site.ts, products.ts, projects.ts, updates.ts
  data/store.ts       # data layer (merges admin localStorage preview)
  components/         # SEO, Layout (header/footer), ProductCard, CoverArt, …
  pages/              # Home, About, Products, ProductDetail, Projects,
                      # Updates, Contact, Privacy, NotFound
  admin/              # /admin dashboard (forms, export/import)
  styles/             # base.css, components.css, pages.css, admin.css
public/               # favicon.svg, og-image.svg, robots.txt, sitemap.xml
```

## Notes

- Dark theme by default, light/dark toggle persisted in `localStorage`,
  `prefers-reduced-motion` respected, mobile-first responsive CSS.
- SEO: per-route titles/descriptions, Open Graph + Twitter cards, canonical
  URLs, semantic HTML, `sitemap.xml`, `robots.txt`.
