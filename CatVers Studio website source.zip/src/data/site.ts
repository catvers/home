import type { CategoryInfo, SiteInfo } from '../types';

/**
 * Site-wide information. Edit values here to update the whole website.
 * Note: CatVers Studio is an independent, remotely managed studio with no
 * public physical office — do not add an address, phone number, or staff.
 */
export const site: SiteInfo = {
  name: 'CatVers Studio',
  tagline: 'Building useful digital products with AI and technology.',
  description:
    'CatVers Studio is an independent software studio managed by Asis Kumar Singh, creating simple and practical digital products designed to solve everyday problems.',
  manager: 'Asis Kumar Singh',
  managerRole: 'Manager & Builder of CatVers Studio',
  managerBio:
    'Asis Kumar Singh manages and builds everything at CatVers Studio — from the first idea to design, development, and release. The studio uses modern technology and AI-assisted development to turn everyday problems into simple, practical products.',
  email: 'asisasastudent@gmail.com',
  // TODO: replace with the real production domain before launch.
  url: 'https://catvers.studio',
};

/** Product categories shown in the "What we build" section and product filters. */
export const categories: CategoryInfo[] = [
  {
    name: 'Productivity',
    description: 'Tools that help people organize and manage everyday tasks.',
    icon: 'check',
  },
  {
    name: 'Education',
    description: 'Useful tools for students, teachers, coaching centres, and institutes.',
    icon: 'book',
  },
  {
    name: 'Finance & Tracking',
    description: 'Simple tools for tracking expenses and personal records.',
    icon: 'chart',
  },
  {
    name: 'Utilities',
    description: 'Small applications that solve common everyday problems.',
    icon: 'wrench',
  },
  {
    name: 'AI-Powered',
    description: 'Applications that use AI to make tasks easier and smarter.',
    icon: 'spark',
  },
  {
    name: 'Experimental',
    description: 'Interesting tools and ideas currently being explored.',
    icon: 'flask',
  },
];

export const navLinks = [
  { to: '/', label: 'Home' },
  { to: '/products', label: 'Products' },
  { to: '/projects', label: 'Projects' },
  { to: '/updates', label: 'Updates' },
  { to: '/about', label: 'About' },
];
