import type { UpdateEntry } from '../types';

/**
 * Updates / changelog. Newest first.
 *
 * Add an entry at the top of this array to publish a launch, feature,
 * milestone, or announcement. Set `published: false` to keep a draft
 * hidden from the public site.
 */
export const updates: UpdateEntry[] = [
  {
    id: 'now-building-my-expenses',
    slug: 'now-building-my-expenses',
    title: 'Now in development: My Expenses',
    date: '2026-10-08',
    excerpt:
      'Work has started on My Expenses, a simple personal expense tracking application.',
    content: `Development has started on My Expenses, a personal expense tracking application from CatVers Studio.

The goal is a tracker that stays out of your way: record spending in seconds, organize it with simple categories, and see totals by day, week, and month.

More details, including early previews, will be shared here as the work progresses.`,
    relatedProductSlug: 'my-expenses',
    image: null,
    tags: ['development', 'my-expenses', 'finance'],
    published: true,
  },
  {
    id: 'catvers-studio-online',
    slug: 'catvers-studio-online',
    title: 'CatVers Studio is online',
    date: '2026-10-08',
    excerpt:
      'The official CatVers Studio website is live — the home for everything the studio builds.',
    content: `CatVers Studio now has an official home on the web.

This website is where the studio will share its products, projects, and updates. New launches will appear in Recently Published, work in progress in Currently Building, and announcements in the Updates timeline.

The first published product, Age Calculator, is already listed. More products are on the way.`,
    relatedProductSlug: 'age-calculator',
    image: null,
    tags: ['studio', 'launch', 'announcement'],
    published: true,
  },
];

export function getPublishedUpdates(list: UpdateEntry[]): UpdateEntry[] {
  return list
    .filter((u) => u.published)
    .sort((a, b) => b.date.localeCompare(a.date));
}
