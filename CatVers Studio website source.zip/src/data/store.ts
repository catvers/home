/**
 * Content store — the data layer of the site.
 *
 * Public pages never import the raw data files directly; they call the
 * getters below. By default the getters return the static content from
 * `src/data/*.ts`. When the admin dashboard saves changes, they are kept in
 * `localStorage` as an override and merged on top of the static content, so
 * edits can be previewed instantly without a rebuild.
 *
 * There is no server or database here. To make admin edits permanent,
 * export the JSON from /admin and paste it back into `src/data/*.ts`
 * (or wire these getters to a real backend later — see src/admin/README).
 */
import { products as staticProducts } from './products';
import { projects as staticProjects } from './projects';
import { updates as staticUpdates } from './updates';
import { site as staticSite } from './site';
import type { Product, Project, SiteInfo, UpdateEntry } from '../types';

export interface ContentSnapshot {
  products: Product[];
  projects: Project[];
  updates: UpdateEntry[];
  site: SiteInfo;
}

const STORAGE_KEY = 'catvers_admin_v1';

function isBrowser(): boolean {
  return typeof window !== 'undefined' && typeof window.localStorage !== 'undefined';
}

export function readOverrides(): Partial<ContentSnapshot> | null {
  if (!isBrowser()) return null;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<ContentSnapshot>;
    if (typeof parsed !== 'object' || parsed === null) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function writeOverrides(snapshot: ContentSnapshot): void {
  if (!isBrowser()) return;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot));
}

export function clearOverrides(): void {
  if (!isBrowser()) return;
  window.localStorage.removeItem(STORAGE_KEY);
}

export function hasOverrides(): boolean {
  return readOverrides() !== null;
}

/** Merge static content with admin overrides (overrides win). */
export function getContent(): ContentSnapshot {
  const overrides = readOverrides();
  return {
    products: Array.isArray(overrides?.products) ? overrides.products : staticProducts,
    projects: Array.isArray(overrides?.projects) ? overrides.projects : staticProjects,
    updates: Array.isArray(overrides?.updates) ? overrides.updates : staticUpdates,
    site:
      overrides?.site && typeof overrides.site === 'object'
        ? { ...staticSite, ...overrides.site }
        : staticSite,
  };
}

export function getProducts(): Product[] {
  return getContent().products;
}
export function getProjects(): Project[] {
  return getContent().projects;
}
export function getUpdates(): UpdateEntry[] {
  return getContent().updates;
}
export function getSite(): SiteInfo {
  return getContent().site;
}
