import type { Product } from '../types';

/**
 * Product catalogue.
 *
 * HOW TO ADD A NEW PRODUCT:
 * 1. Copy one of the entries below and paste it at the top of this array.
 * 2. Change `id`, `slug` (URL-safe, lowercase), `name`, descriptions,
 *    `category`, `platform`, and `status`.
 * 3. Leave `websiteUrl` / `downloadUrl` as null until a real link exists —
 *    the buttons are hidden automatically, never shown as dead links.
 * 4. Set `featured: true` to show it in the home-page showcase,
 *    `published: false` to hide it from the public site entirely.
 * 5. Save. The product appears on the Products page, in search, filters,
 *    the Recently Published list, related products, and gets its own page
 *    at /products/<slug>. No other files need editing.
 *
 * Do not invent launch dates, user counts, ratings, or awards.
 * Leave fields as null when the information is not available yet.
 */
export const products: Product[] = [
  {
    id: 'age-calculator',
    slug: 'age-calculator',
    name: 'Age Calculator',
    shortDescription: 'A simple tool for calculating age accurately.',
    longDescription:
      'Age Calculator is a straightforward utility that calculates age from a date of birth. It shows the result in years, months, and days, and is designed to be fast, private, and easy to use on any device. There is no sign-up and no data leaves your browser.',
    category: 'Utilities',
    platform: 'Web',
    status: 'published',
    logo: '',
    coverImage: '',
    screenshots: [],
    websiteUrl: null,
    downloadUrl: null,
    sourceUrl: null,
    launchDate: null,
    lastUpdated: null,
    features: [
      'Calculates age in years, months, and days',
      'Clean, distraction-free interface',
      'Works on phones, tablets, and desktops',
      'Private — your dates never leave your device',
    ],
    tags: ['calculator', 'utility', 'web'],
    featured: true,
    published: true,
    accent: 'indigo',
  },
  {
    id: 'my-expenses',
    slug: 'my-expenses',
    name: 'My Expenses',
    shortDescription:
      'A personal expense tracking application designed to help users manage their spending.',
    longDescription:
      'My Expenses is a personal expense tracker focused on simplicity. It helps you record daily spending, see where your money goes, and stay in control of your budget — without complicated setup or unnecessary features.',
    category: 'Finance & Tracking',
    platform: 'Web',
    status: 'in-development',
    logo: '',
    coverImage: '',
    screenshots: [],
    websiteUrl: null,
    downloadUrl: null,
    sourceUrl: null,
    launchDate: null,
    lastUpdated: null,
    features: [
      'Record income and expenses in seconds',
      'Organize spending with simple categories',
      'View totals by day, week, and month',
      'Designed to work well on mobile',
    ],
    tags: ['finance', 'tracker', 'budget', 'web'],
    featured: true,
    published: true,
    accent: 'emerald',
  },
  {
    id: 'fee-registry',
    slug: 'coaching-institute-fee-registry',
    name: 'Coaching / Institute Student Fee Registry',
    shortDescription:
      'A management application for maintaining student information, fees, attendance, and payment records.',
    longDescription:
      'The Coaching / Institute Student Fee Registry is being designed for coaching centres and institutes that still manage fees on paper or spreadsheets. It will keep student information, fee schedules, attendance, and payment records in one organized place that is easy to search and update.',
    category: 'Education',
    platform: 'Web',
    status: 'coming-soon',
    logo: '',
    coverImage: '',
    screenshots: [],
    websiteUrl: null,
    downloadUrl: null,
    sourceUrl: null,
    launchDate: null,
    lastUpdated: null,
    features: [
      'Student profiles with contact details',
      'Fee schedules and payment tracking',
      'Attendance records',
      'Search and filter across all records',
    ],
    tags: ['education', 'coaching', 'fees', 'management'],
    featured: false,
    published: true,
    accent: 'amber',
  },
];

/** Visible products, newest launches first (entries without a launch date last). */
export function getPublishedProducts(list: Product[]): Product[] {
  return list
    .filter((p) => p.published)
    .sort((a, b) => {
      if (a.launchDate && b.launchDate) return b.launchDate.localeCompare(a.launchDate);
      if (a.launchDate) return -1;
      if (b.launchDate) return 1;
      return 0;
    });
}

export function getFeaturedProducts(list: Product[]): Product[] {
  return list.filter((p) => p.published && p.featured);
}

export function getProductsByStatus(
  list: Product[],
  statuses: Product['status'][],
): Product[] {
  return list.filter((p) => p.published && statuses.includes(p.status));
}

export function getRelatedProducts(list: Product[], product: Product, count = 3): Product[] {
  return list
    .filter(
      (p) =>
        p.published &&
        p.id !== product.id &&
        (p.category === product.category ||
          p.tags.some((t) => product.tags.includes(t))),
    )
    .slice(0, count);
}
