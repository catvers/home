import type { Project } from '../types';

/**
 * Projects — separate from Products. Websites, experiments, internal tools,
 * concept work and unreleased ideas live here.
 *
 * Add entries the same way as products: copy an entry, change the fields,
 * save. Set `published: false` to hide an entry from the public site.
 */
export const projects: Project[] = [
  {
    id: 'catvers-website',
    slug: 'catvers-studio-website',
    name: 'CatVers Studio Website',
    description:
      'The official online home of CatVers Studio — a fast, accessible, mobile-first website that presents the studio, its products, and its updates. Built with React, TypeScript, and modern web standards.',
    status: 'published',
    category: 'Website',
    image: '',
    date: null,
    link: null,
    published: true,
    accent: 'violet',
  },
  {
    id: 'ai-experiments',
    slug: 'ai-product-experiments',
    name: 'AI-Assisted Product Experiments',
    description:
      'Ongoing exploration of how AI-assisted development can make everyday tools smarter — from idea to working prototype. Experiments that prove useful may grow into full products.',
    status: 'experimental',
    category: 'Experimental',
    image: '',
    date: null,
    link: null,
    published: true,
    accent: 'sky',
  },
];
