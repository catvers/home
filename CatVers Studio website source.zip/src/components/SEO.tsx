import { useEffect } from 'react';
import { getSite } from '../data/store';

interface SEOProps {
  /** Page-specific title, e.g. "Products". Site name is appended automatically. */
  title: string;
  description: string;
  /** Route path, e.g. "/products" */
  path: string;
  /** Absolute or root-relative image URL for social previews */
  image?: string;
  /** When true, adds noindex (used for /admin) */
  noIndex?: boolean;
}

function upsertMeta(attr: 'name' | 'property', key: string, content: string) {
  let el = document.head.querySelector<HTMLMetaElement>(
    `meta[${attr}="${key}"]`,
  );
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

function upsertLink(rel: string, href: string) {
  let el = document.head.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}

/**
 * Sets document title, meta description, Open Graph / Twitter tags and the
 * canonical link for the current route. No external library required.
 */
export function SEO({ title, description, path, image, noIndex }: SEOProps) {
  useEffect(() => {
    const site = getSite();
    const fullTitle = path === '/' ? `${site.name} — ${site.tagline}` : `${title} | ${site.name}`;
    const canonical = `${site.url.replace(/\/$/, '')}${path}`;
    const ogImage = image
      ? image.startsWith('http')
        ? image
        : `${site.url.replace(/\/$/, '')}${image}`
      : `${site.url.replace(/\/$/, '')}/og-image.svg`;

    document.title = fullTitle;
    upsertMeta('name', 'description', description);
    upsertMeta('name', 'robots', noIndex ? 'noindex, nofollow' : 'index, follow');
    upsertMeta('property', 'og:site_name', site.name);
    upsertMeta('property', 'og:title', fullTitle);
    upsertMeta('property', 'og:description', description);
    upsertMeta('property', 'og:type', 'website');
    upsertMeta('property', 'og:url', canonical);
    upsertMeta('property', 'og:image', ogImage);
    upsertMeta('name', 'twitter:card', 'summary_large_image');
    upsertMeta('name', 'twitter:title', fullTitle);
    upsertMeta('name', 'twitter:description', description);
    upsertMeta('name', 'twitter:image', ogImage);
    upsertLink('canonical', canonical);
  }, [title, description, path, image, noIndex]);

  return null;
}
