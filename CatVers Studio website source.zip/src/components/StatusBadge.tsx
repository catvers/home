import { STATUS_LABELS, type ProductStatus } from '../types';

const STATUS_CLASS: Record<ProductStatus, string> = {
  published: 'status-published',
  'in-development': 'status-in-development',
  'coming-soon': 'status-coming-soon',
  experimental: 'status-experimental',
  archived: 'status-archived',
};

/** Elegant status pill with a colored dot — no emojis. */
export function StatusBadge({ status }: { status: ProductStatus }) {
  return (
    <span className={`status-badge ${STATUS_CLASS[status]}`}>
      <span className="status-dot" aria-hidden="true" />
      {STATUS_LABELS[status]}
    </span>
  );
}
