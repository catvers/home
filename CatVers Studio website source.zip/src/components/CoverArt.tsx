interface CoverArtProps {
  /** Gradient theme key, e.g. "indigo", "emerald" */
  accent: string;
  /** Product/project name — its initial is used as the monogram */
  name: string;
  className?: string;
}

/**
 * Generated cover art shown when a product or project has no real
 * screenshot yet: a soft gradient with a subtle pattern and the
 * product's initial. Aspect ratio is controlled by the container.
 */
export function CoverArt({ accent, name, className = '' }: CoverArtProps) {
  const initial = (name.trim().charAt(0) || 'C').toUpperCase();
  return (
    <div
      className={`cover-art cover-art--${accent} ${className}`}
      role="img"
      aria-label={`${name} cover art`}
    >
      <span className="cover-art__pattern" aria-hidden="true" />
      <span className="cover-art__monogram" aria-hidden="true">
        {initial}
      </span>
      <span className="cover-art__glow" aria-hidden="true" />
    </div>
  );
}
