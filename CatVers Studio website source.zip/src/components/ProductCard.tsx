import { Link } from 'react-router-dom';
import type { Product } from '../types';
import { CoverArt } from './CoverArt';
import { StatusBadge } from './StatusBadge';
import { IconArrowRight, IconDownload, IconExternal } from './icons';

/**
 * Product card rendered purely from product data.
 * Link buttons only appear when a real URL exists — no dead buttons.
 */
export function ProductCard({ product }: { product: Product }) {
  const hasLink = Boolean(product.websiteUrl || product.downloadUrl);
  return (
    <article className="product-card">
      <Link
        to={`/products/${product.slug}`}
        className="product-card__media"
        aria-label={`View ${product.name}`}
        tabIndex={-1}
      >
        {product.coverImage ? (
          <img
            src={product.coverImage}
            alt={`${product.name} preview`}
            loading="lazy"
            className="product-card__img"
          />
        ) : (
          <CoverArt accent={product.accent} name={product.name} />
        )}
      </Link>
      <div className="product-card__body">
        <div className="product-card__top">
          <StatusBadge status={product.status} />
          <span className="product-card__platform">{product.platform}</span>
        </div>
        <h3 className="product-card__name">
          <Link to={`/products/${product.slug}`}>{product.name}</Link>
        </h3>
        <p className="product-card__desc">{product.shortDescription}</p>
        <p className="product-card__category">{product.category}</p>
        <div className="product-card__actions">
          <Link to={`/products/${product.slug}`} className="btn btn--small btn--primary">
            View Product <IconArrowRight size={15} />
          </Link>
          {product.websiteUrl && (
            <a
              href={product.websiteUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn--small btn--ghost"
            >
              Visit <IconExternal size={14} />
            </a>
          )}
          {product.downloadUrl && (
            <a href={product.downloadUrl} className="btn btn--small btn--ghost">
              Download <IconDownload size={14} />
            </a>
          )}
          {!hasLink && product.status !== 'published' && (
            <span className="product-card__soon">Link coming soon</span>
          )}
        </div>
      </div>
    </article>
  );
}
