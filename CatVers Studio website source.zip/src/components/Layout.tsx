import { useEffect, useState, type ReactNode } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { navLinks } from '../data/site';
import { getSite } from '../data/store';
import type { Theme } from '../hooks/useTheme';
import { IconClose, IconMail, IconMenu, IconMoon, IconSun, LogoMark } from './icons';

interface LayoutProps {
  children: ReactNode;
  theme: Theme;
  onToggleTheme: () => void;
}

function Header({ theme, onToggleTheme }: { theme: Theme; onToggleTheme: () => void }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();
  const site = getSite();

  // Close the mobile menu on navigation and unlock scrolling.
  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [menuOpen]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMenuOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <header className="site-header">
      <div className="container site-header__inner">
        <Link to="/" className="brand" aria-label={`${site.name} — home`}>
          <LogoMark size={34} />
          <span className="brand__wordmark">
            CatVers <span className="brand__wordmark-accent">Studio</span>
          </span>
        </Link>

        <nav className="site-nav" aria-label="Primary">
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.to === '/'}
              className={({ isActive }) => `site-nav__link${isActive ? ' is-active' : ''}`}
            >
              {link.label}
            </NavLink>
          ))}
        </nav>

        <div className="site-header__actions">
          <Link to="/contact" className="btn btn--small btn--primary site-header__contact">
            Contact
          </Link>
          <button
            type="button"
            className="icon-btn"
            onClick={onToggleTheme}
            aria-label={theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'}
            title={theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'}
          >
            {theme === 'dark' ? <IconSun size={19} /> : <IconMoon size={19} />}
          </button>
          <button
            type="button"
            className="icon-btn site-header__menu-btn"
            onClick={() => setMenuOpen((v) => !v)}
            aria-expanded={menuOpen}
            aria-controls="mobile-menu"
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
          >
            {menuOpen ? <IconClose size={21} /> : <IconMenu size={21} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <div
        id="mobile-menu"
        className={`mobile-menu${menuOpen ? ' is-open' : ''}`}
        aria-hidden={!menuOpen}
      >
        <nav className="mobile-menu__nav" aria-label="Mobile">
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.to === '/'}
              tabIndex={menuOpen ? 0 : -1}
              className={({ isActive }) =>
                `mobile-menu__link${isActive ? ' is-active' : ''}`
              }
            >
              {link.label}
            </NavLink>
          ))}
          <Link
            to="/contact"
            tabIndex={menuOpen ? 0 : -1}
            className="btn btn--primary mobile-menu__contact"
          >
            Contact
          </Link>
          <a
            href={`mailto:${site.email}`}
            tabIndex={menuOpen ? 0 : -1}
            className="mobile-menu__email"
          >
            <IconMail size={16} /> {site.email}
          </a>
        </nav>
      </div>
    </header>
  );
}

function Footer() {
  const site = getSite();
  const year = new Date().getFullYear();
  return (
    <footer className="site-footer">
      <div className="container">
        <div className="site-footer__grid">
          <div className="site-footer__brand">
            <Link to="/" className="brand" aria-label={`${site.name} — home`}>
              <LogoMark size={30} />
              <span className="brand__wordmark">
                CatVers <span className="brand__wordmark-accent">Studio</span>
              </span>
            </Link>
            <p className="site-footer__tagline">{site.tagline}</p>
            <p className="site-footer__managed">Managed by {site.manager}</p>
            <a className="site-footer__email" href={`mailto:${site.email}`}>
              <IconMail size={15} /> {site.email}
            </a>
          </div>
          <nav className="site-footer__nav" aria-label="Footer">
            <div className="site-footer__col">
              <h3 className="site-footer__heading">Studio</h3>
              <Link to="/">Home</Link>
              <Link to="/about">About</Link>
              <Link to="/contact">Contact</Link>
              <Link to="/privacy">Privacy</Link>
            </div>
            <div className="site-footer__col">
              <h3 className="site-footer__heading">Work</h3>
              <Link to="/products">Products</Link>
              <Link to="/projects">Projects</Link>
              <Link to="/updates">Updates</Link>
            </div>
          </nav>
        </div>
        <div className="site-footer__bottom">
          <p>© {year} {site.name}. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

export function Layout({ children, theme, onToggleTheme }: LayoutProps) {
  return (
    <>
      <a className="skip-link" href="#main-content">
        Skip to main content
      </a>
      <Header theme={theme} onToggleTheme={onToggleTheme} />
      <main id="main-content">{children}</main>
      <Footer />
    </>
  );
}
