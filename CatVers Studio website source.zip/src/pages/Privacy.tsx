import { SEO } from '../components/SEO';
import { Reveal } from '../components/Reveal';
import { getSite } from '../data/store';

export function Privacy() {
  const site = getSite();

  return (
    <>
      <SEO
        title="Privacy Policy"
        description={`Privacy policy for the ${site.name} website — what data is collected (very little), how it is used, and how to contact us.`}
        path="/privacy"
      />
      <div className="container page page--narrow">
        <Reveal>
          <header className="page__header">
            <p className="section__eyebrow">Legal</p>
            <h1 className="page__title">Privacy Policy</h1>
            <p className="page__lede">Last updated: 8 Oct 2026</p>
          </header>
        </Reveal>

        <Reveal>
          <article className="prose">
            <p>
              {site.name} ("we", "our") respects your privacy. This policy
              explains what information this website collects and how it is
              used. If you have questions, contact us at{' '}
              <a href={`mailto:${site.email}`}>{site.email}</a>.
            </p>

            <h2>Information we collect</h2>
            <p>
              This website does not require accounts, does not run analytics
              trackers, and does not sell or share personal information. The
              limited information involved in using this site is:
            </p>
            <ul>
              <li>
                <strong>Theme preference.</strong> Your light/dark theme choice
                is stored in your browser's local storage so the site remembers
                it. It never leaves your device.
              </li>
              <li>
                <strong>Contact emails.</strong> If you email us at{' '}
                {site.email}, we receive whatever you choose to include in that
                email. We use it only to reply to you.
              </li>
              <li>
                <strong>Basic technical data.</strong> Like every website, the
                hosting provider may log standard technical information (such
                as IP addresses) needed to serve pages securely. We do not use
                this to identify or profile visitors.
              </li>
            </ul>

            <h2>Cookies</h2>
            <p>
              This website does not set advertising or tracking cookies. The
              theme preference described above is stored with local storage,
              not cookies.
            </p>

            <h2>Third-party links</h2>
            <p>
              Product pages may link to external websites (for example, a
              product's own website or a download page). We are not responsible
              for the privacy practices of those external sites.
            </p>

            <h2>Children</h2>
            <p>
              This website is a general-audience studio site and does not
              knowingly collect information from children.
            </p>

            <h2>Changes to this policy</h2>
            <p>
              If this policy changes, the updated version will be posted on
              this page with a new "last updated" date.
            </p>

            <h2>Contact</h2>
            <p>
              For any privacy question, email{' '}
              <a href={`mailto:${site.email}`}>{site.email}</a>.
            </p>
          </article>
        </Reveal>
      </div>
    </>
  );
}
