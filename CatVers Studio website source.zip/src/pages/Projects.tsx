import { SEO } from '../components/SEO';
import { Reveal } from '../components/Reveal';
import { CoverArt } from '../components/CoverArt';
import { StatusBadge } from '../components/StatusBadge';
import { EmptyState } from '../components/EmptyState';
import { IconExternal } from '../components/icons';
import { getProjects } from '../data/store';
import { formatDate } from '../lib/format';

export function Projects() {
  const projects = getProjects().filter((p) => p.published);

  return (
    <>
      <SEO
        title="Projects"
        description="Experiments, websites, internal tools, and concept work from CatVers Studio — separate from the published product catalogue."
        path="/projects"
      />
      <div className="container page">
        <Reveal>
          <header className="page__header">
            <p className="section__eyebrow">Lab</p>
            <h1 className="page__title">Projects</h1>
            <p className="page__lede">
              Experiments, websites, internal tools, and concept work — the
              ideas being explored behind the scenes. Projects that prove
              useful may grow into full products.
            </p>
          </header>
        </Reveal>

        {projects.length === 0 ? (
          <EmptyState
            title="No projects available"
            message="There are no public projects to show right now. Experiments and concept work will appear here as they take shape."
          />
        ) : (
          <div className="card-grid">
            {projects.map((p, i) => (
              <Reveal key={p.id} delay={Math.min(i * 80, 240)}>
                <article className="project-card">
                  <div className="project-card__media">
                    {p.image ? (
                      <img src={p.image} alt={`${p.name} preview`} loading="lazy" />
                    ) : (
                      <CoverArt accent={p.accent} name={p.name} />
                    )}
                  </div>
                  <div className="project-card__body">
                    <div className="project-card__top">
                      <StatusBadge status={p.status} />
                      {p.date && formatDate(p.date) && (
                        <span className="project-card__date">{formatDate(p.date)}</span>
                      )}
                    </div>
                    <h2 className="project-card__name">{p.name}</h2>
                    <p className="project-card__desc">{p.description}</p>
                    <div className="project-card__foot">
                      <span className="project-card__category">{p.category}</span>
                      {p.link && (
                        <a
                          href={p.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="link-more"
                        >
                          Visit <IconExternal size={14} />
                        </a>
                      )}
                    </div>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        )}
      </div>
    </>
  );
}
