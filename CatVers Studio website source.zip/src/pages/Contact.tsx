import { useState, type FormEvent } from 'react';
import { SEO } from '../components/SEO';
import { Reveal } from '../components/Reveal';
import { IconInfo, IconMail } from '../components/icons';
import { getSite } from '../data/store';
import { buildMailto } from '../lib/format';

/**
 * Contact page.
 *
 * There is no custom backend by design, so the form composes a `mailto:`
 * link prefilled with the visitor's name and message and opens it in the
 * visitor's own email app. To connect a real backend later, replace
 * `handleSubmit` with a POST to your form endpoint (e.g. Formspree,
 * Web3Forms, or your own API) — the form fields are already named for that.
 */
export function Contact() {
  const site = getSite();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const body = [`Name: ${name}`, `Email: ${email}`, '', message].join('\n');
    window.location.href = buildMailto(
      site.email,
      subject || `Message from ${name || 'the CatVers Studio website'}`,
      body,
    );
  };

  return (
    <>
      <SEO
        title="Contact"
        description={`Contact ${site.name} — managed by ${site.manager}. Send an email with questions, ideas, or feedback about our products.`}
        path="/contact"
      />
      <div className="container page">
        <Reveal>
          <header className="page__header">
            <p className="section__eyebrow">Get in touch</p>
            <h1 className="page__title">Let's build something useful.</h1>
            <p className="page__lede">
              Questions about a product, an idea worth building, or just
              feedback? {site.name} is managed by {site.manager} — your message
              goes straight to the person building the products.
            </p>
          </header>
        </Reveal>

        <div className="contact-grid">
          <Reveal>
            <div className="contact-card">
              <h2 className="contact-card__title">Email us directly</h2>
              <p className="contact-card__text">
                The fastest way to reach {site.name}.
              </p>
              <a
                href={`mailto:${site.email}?subject=${encodeURIComponent('Hello from the CatVers Studio website')}`}
                className="btn btn--primary btn--large btn--block"
              >
                <IconMail size={18} /> {site.email}
              </a>
              <p className="contact-card__note">
                {site.name} is an independent, remotely managed studio and does
                not operate from a public office — email is the best way to get
                in touch.
              </p>
            </div>
          </Reveal>

          <Reveal delay={120}>
            <form className="contact-form" onSubmit={handleSubmit} aria-label="Contact form">
              <h2 className="contact-card__title">Or send a message</h2>
              <div className="form-row">
                <label className="form-field">
                  <span className="form-field__label">Your name</span>
                  <input
                    type="text"
                    name="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Jane Doe"
                    required
                    autoComplete="name"
                  />
                </label>
                <label className="form-field">
                  <span className="form-field__label">Your email</span>
                  <input
                    type="email"
                    name="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="jane@example.com"
                    required
                    autoComplete="email"
                  />
                </label>
              </div>
              <label className="form-field">
                <span className="form-field__label">Subject</span>
                <input
                  type="text"
                  name="subject"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="What is this about?"
                />
              </label>
              <label className="form-field">
                <span className="form-field__label">Message</span>
                <textarea
                  name="message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Write your message here…"
                  rows={6}
                  required
                />
              </label>
              <button type="submit" className="btn btn--primary btn--large btn--block">
                <IconMail size={18} /> Compose email
              </button>
              <p className="form-note">
                <IconInfo size={14} />
                Submitting opens your email app with the message prefilled and
                addressed to {site.email}. Nothing is sent until you press send
                in your email app.
              </p>
            </form>
          </Reveal>
        </div>
      </div>
    </>
  );
}
