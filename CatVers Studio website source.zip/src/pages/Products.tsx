import { useMemo, useState } from 'react';
import { SEO } from '../components/SEO';
import { Reveal } from '../components/Reveal';
import { ProductCard } from '../components/ProductCard';
import { EmptyState } from '../components/EmptyState';
import { IconSearch } from '../components/icons';
import { STATUS_LABELS, PRODUCT_STATUSES, type ProductStatus } from '../types';
import { getProducts } from '../data/store';
import { getPublishedProducts } from '../data/products';

type StatusFilter = 'all' | ProductStatus;

export function Products() {
  const all = useMemo(() => getPublishedProducts(getProducts()), []);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('all');
  const [status, setStatus] = useState<StatusFilter>('all');
  const [platform, setPlatform] = useState('all');

  const categories = useMemo(
    () => Array.from(new Set(all.map((p) => p.category))).sort(),
    [all],
  );
  const platforms = useMemo(
    () => Array.from(new Set(all.map((p) => p.platform))).sort(),
    [all],
  );
  const statuses = useMemo(
    () =>
      PRODUCT_STATUSES.filter((s) => all.some((p) => p.status === s)),
    [all],
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return all.filter((p) => {
      if (category !== 'all' && p.category !== category) return false;
      if (status !== 'all' && p.status !== status) return false;
      if (platform !== 'all' && p.platform !== platform) return false;
      if (!q) return true;
      const haystack =
        `${p.name} ${p.shortDescription} ${p.longDescription} ${p.category} ${p.tags.join(' ')}`.toLowerCase();
      return q.split(/\s+/).every((word) => haystack.includes(word));
    });
  }, [all, query, category, status, platform]);

  const hasFilters = query !== '' || category !== 'all' || status !== 'all' || platform !== 'all';

  const clearFilters = () => {
    setQuery('');
    setCategory('all');
    setStatus('all');
    setPlatform('all');
  };

  return (
    <>
      <SEO
        title="Products"
        description="Browse every product published by CatVers Studio — simple, practical tools for everyday life. Search and filter by category, status, and platform."
        path="/products"
      />
      <div className="container page">
        <Reveal>
          <header className="page__header">
            <p className="section__eyebrow">Catalogue</p>
            <h1 className="page__title">Products</h1>
            <p className="page__lede">
              Every product built by CatVers Studio, from published tools to
              works in progress. Search, filter, and explore.
            </p>
          </header>
        </Reveal>

        {all.length === 0 ? (
          <EmptyState
            title="No products published yet"
            message="CatVers Studio is working on its first releases. Check back soon — new products will appear here first."
          />
        ) : (
          <>
            <div className="filters" role="search" aria-label="Search and filter products">
              <label className="filters__search">
                <IconSearch size={18} />
                <span className="visually-hidden">Search products</span>
                <input
                  type="search"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search products…"
                  aria-label="Search products"
                />
              </label>
              <div className="filters__row">
                <label className="filters__select">
                  <span className="filters__label">Category</span>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    aria-label="Filter by category"
                  >
                    <option value="all">All categories</option>
                    {categories.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="filters__select">
                  <span className="filters__label">Status</span>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as StatusFilter)}
                    aria-label="Filter by status"
                  >
                    <option value="all">All statuses</option>
                    {statuses.map((s) => (
                      <option key={s} value={s}>
                        {STATUS_LABELS[s]}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="filters__select">
                  <span className="filters__label">Platform</span>
                  <select
                    value={platform}
                    onChange={(e) => setPlatform(e.target.value)}
                    aria-label="Filter by platform"
                  >
                    <option value="all">All platforms</option>
                    {platforms.map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </label>
                {hasFilters && (
                  <button type="button" className="btn btn--small btn--ghost" onClick={clearFilters}>
                    Clear filters
                  </button>
                )}
              </div>
            </div>

            <p className="results-count" role="status" aria-live="polite">
              {filtered.length === 1
                ? '1 product'
                : `${filtered.length} products`}
              {hasFilters && ' matching your filters'}
            </p>

            {filtered.length === 0 ? (
              <EmptyState
                title="No products match your filters"
                message="Try a different search term or clear the filters to see everything."
                action={
                  <button type="button" className="btn btn--primary" onClick={clearFilters}>
                    Clear all filters
                  </button>
                }
              />
            ) : (
              <div className="card-grid">
                {filtered.map((p, i) => (
                  <Reveal key={p.id} delay={Math.min((i % 6) * 60, 300)}>
                    <ProductCard product={p} />
                  </Reveal>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </>
  );
}
