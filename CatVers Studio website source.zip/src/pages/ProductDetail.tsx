import { Link, Navigate, useParams } from 'react-router-dom';
import { SEO } from '../components/SEO';
import { Reveal } from '../components/Reveal';
import { ProductCard } from '../components/ProductCard';
import { CoverArt } from '../components/CoverArt';
import { StatusBadge } from '../components/StatusBadge';
import {
  IconArrowLeft,
  IconCalendar,
  IconCheck,
  IconDevice,
  IconDownload,
  IconExternal,
} from '../components/icons';
import { getProducts } from '../data/store';
import { getRelatedProducts } from '../data/products';
import { formatDate } from '../lib/format';

export function ProductDetail() {
  const { slug } = useParams<{ slug: string }>();
  const products = getProducts();
  const product = products.find((p) => p.slug === slug && p.published);

  if (!product) {
    return <Navigate to="/404" replace />;
  }

  const related = getRelatedProducts(products, product);
  const launchDate = formatDate(product.launchDate);
  const lastUpdated = formatDate(product.lastUpdated);

  return (
    <>
      <SEO
        title={product.name}
        description={product.shortDescription}
        path={`/products/${product.slug}`}
        image={product.coverImage || undefined}
      />
      <div className="container page">
        <Reveal>
          <Link to="/products" className="back-link">
            <IconArrowLeft size={16} /> Back to products
          </Link>
        </Reveal>

        <article className="product-detail">
          <Reveal>
            <header className="product-detail__header">
              <div className="product-detail__identity">
                {product.logo ? (
                  <img
                    src={product.logo}
                    alt={`${product.name} logo`}
                    className="product-detail__logo"
                  />
                ) : (
                  <span
                    className={`product-detail__monogram product-detail__monogram--${product.accent}`}
                    aria-hidden="true"
                  >
                    {product.name.trim().charAt(0).toUpperCase()}
                  </span>
                )}
                <div>
                  <h1 className="product-detail__name">{product.name}</h1>
                  <div className="product-detail__badges">
                    <StatusBadge status={product.status} />
                    <span className="product-detail__category">{product.category}</span>
                  </div>
                </div>
              </div>
              <p className="product-detail__short">{product.shortDescription}</p>
            </header>
          </Reveal>

          <Reveal>
            <div className="product-detail__cover">
              {product.coverImage ? (
                <img
                  src={product.coverImage}
                  alt={`${product.name} preview`}
                  loading="lazy"
                  className="product-detail__cover-img"
                />
              ) : (
                <CoverArt
                  accent={product.accent}
                  name={product.name}
                  className="product-detail__cover-art"
                />
              )}
            </div>
          </Reveal>

          <div className="product-detail__grid">
            <div className="product-detail__main">
              <Reveal>
                <section aria-labelledby="about-product">
                  <h2 id="about-product" className="product-detail__h2">
                    About the product
                  </h2>
                  <p className="product-detail__long">{product.longDescription}</p>
                </section>
              </Reveal>

              {product.features.length > 0 && (
                <Reveal>
                  <section aria-labelledby="product-features">
                    <h2 id="product-features" className="product-detail__h2">
                      Features
                    </h2>
                    <ul className="feature-list">
                      {product.features.map((f) => (
                        <li key={f} className="feature-list__item">
                          <span className="feature-list__icon" aria-hidden="true">
                            <IconCheck size={16} />
                          </span>
                          {f}
                        </li>
                      ))}
                    </ul>
                  </section>
                </Reveal>
              )}

              {product.screenshots.length > 0 && (
                <Reveal>
                  <section aria-labelledby="product-screenshots">
                    <h2 id="product-screenshots" className="product-detail__h2">
                      Screenshots
                    </h2>
                    <div className="screenshot-grid">
                      {product.screenshots.map((src, i) => (
                        <img
                          key={src}
                          src={src}
                          alt={`${product.name} screenshot ${i + 1}`}
                          loading="lazy"
                          className="screenshot-grid__img"
                        />
                      ))}
                    </div>
                  </section>
                </Reveal>
              )}
            </div>

            <aside className="product-detail__aside" aria-label="Product information">
              <Reveal>
                <div className="info-card">
                  <h2 className="info-card__title">Details</h2>
                  <dl className="info-list">
                    <div className="info-list__row">
                      <dt>Status</dt>
                      <dd>
                        <StatusBadge status={product.status} />
                      </dd>
                    </div>
                    <div className="info-list__row">
                      <dt>Platform</dt>
                      <dd>
                        <span className="info-list__icon" aria-hidden="true">
                          <IconDevice size={14} />
                        </span>
                        {product.platform}
                      </dd>
                    </div>
                    <div className="info-list__row">
                      <dt>Category</dt>
                      <dd>{product.category}</dd>
                    </div>
                    {launchDate && (
                      <div className="info-list__row">
                        <dt>Launched</dt>
                        <dd>
                          <span className="info-list__icon" aria-hidden="true">
                            <IconCalendar size={14} />
                          </span>
                          {launchDate}
                        </dd>
                      </div>
                    )}
                    {lastUpdated && (
                      <div className="info-list__row">
                        <dt>Last updated</dt>
                        <dd>{lastUpdated}</dd>
                      </div>
                    )}
                  </dl>
                  <div className="info-card__actions">
                    {product.websiteUrl && (
                      <a
                        href={product.websiteUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn btn--primary btn--block"
                      >
                        Visit Website <IconExternal size={15} />
                      </a>
                    )}
                    {product.downloadUrl && (
                      <a href={product.downloadUrl} className="btn btn--ghost btn--block">
                        Download <IconDownload size={15} />
                      </a>
                    )}
                    {!product.websiteUrl && !product.downloadUrl && (
                      <p className="info-card__note">
                        {product.status === 'published'
                          ? 'Links for this product will be added soon.'
                          : 'This product is not released yet — check back for links.'}
                      </p>
                    )}
                  </div>
                  {product.tags.length > 0 && (
                    <div className="tag-row" aria-label="Tags">
                      {product.tags.map((t) => (
                        <span key={t} className="tag">
                          {t}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </Reveal>
            </aside>
          </div>

          {related.length > 0 && (
            <section aria-labelledby="related-products" className="related-section">
              <Reveal>
                <h2 id="related-products" className="product-detail__h2">
                  Related products
                </h2>
              </Reveal>
              <div className="card-grid card-grid--3">
                {related.map((p, i) => (
                  <Reveal key={p.id} delay={Math.min(i * 80, 240)}>
                    <ProductCard product={p} />
                  </Reveal>
                ))}
              </div>
            </section>
          )}
        </article>
      </div>
    </>
  );
}
