import { Link } from 'react-router-dom';
import { SEO } from '../components/SEO';
import { Reveal } from '../components/Reveal';
import { LogoMark, IconArrowRight, IconCheck } from '../components/icons';
import { getSite } from '../data/store';

const PRINCIPLES = [
  { title: 'Useful', text: 'Built to solve real, everyday problems — not to show off technology.' },
  { title: 'Simple', text: 'Easy to understand from the first minute, with no learning curve.' },
  { title: 'Accessible', text: 'Designed to work for everyone, on the devices people actually own.' },
  { title: 'Practical', text: 'Focused on doing a few things well instead of everything poorly.' },
  { title: 'Honest', text: 'No inflated claims, no dark patterns, no fake numbers.' },
];

export function About() {
  const site = getSite();

  return (
    <>
      <SEO
        title="About"
        description={`About ${site.name} — an independent software studio managed by ${site.manager}, building simple, practical digital products with modern technology and AI-assisted development.`}
        path="/about"
      />
      <div className="container page">
        <Reveal>
          <header className="page__header">
            <p className="section__eyebrow">The studio</p>
            <h1 className="page__title">About {site.name}</h1>
            <p className="page__lede">
              {site.name} is an independent software studio managed by{' '}
              {site.manager}. The studio creates useful digital products with
              modern technology and AI-assisted development.
            </p>
          </header>
        </Reveal>

        <Reveal>
          <section className="about-story" aria-labelledby="story-heading">
            <h2 id="story-heading" className="visually-hidden">
              Our story
            </h2>
            <div className="about-story__card">
              <p>
                {site.name} exists for a simple reason: everyday life is full of
                small problems that deserve good tools. An age to calculate, a
                budget to track, student fees to organize — these are the kinds
                of problems the studio takes seriously.
              </p>
              <p>
                The goal is not simply to create software, but to build products
                that are genuinely useful, simple to use, accessible to
                everyone, and practical in daily life.
              </p>
              <p>
                {site.name} is run independently and remotely by {site.manager},
                working from home with personal devices. This keeps the studio
                lean, flexible, and focused entirely on building — no overhead,
                no bureaucracy, just products.
              </p>
            </div>
          </section>
        </Reveal>

        <section aria-labelledby="principles-heading" className="section">
          <Reveal>
            <p className="section__eyebrow">How we build</p>
            <h2 id="principles-heading" className="section__title">
              What every product aims to be
            </h2>
          </Reveal>
          <ul className="principle-list">
            {PRINCIPLES.map((p, i) => (
              <Reveal as="li" key={p.title} delay={Math.min(i * 60, 300)}>
                <div className="principle-card">
                  <span className="principle-card__icon" aria-hidden="true">
                    <IconCheck size={18} />
                  </span>
                  <div>
                    <h3 className="principle-card__title">{p.title}</h3>
                    <p className="principle-card__text">{p.text}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </ul>
        </section>

        <section aria-labelledby="founder-heading" className="section">
          <Reveal>
            <div className="founder-card">
              <div className="founder-card__avatar" aria-hidden="true">
                <LogoMark size={72} />
              </div>
              <div>
                <p className="section__eyebrow">Managed by</p>
                <h2 id="founder-heading" className="section__title">
                  {site.manager}
                </h2>
                <p className="founder-card__role">{site.managerRole}</p>
                <p className="founder-card__bio">{site.managerBio}</p>
              </div>
            </div>
          </Reveal>
        </section>

        <Reveal>
          <div className="cta-band">
            <h2 className="cta-band__title">Let's build something useful.</h2>
            <p className="cta-band__text">
              Questions, ideas, or feedback about a {site.name} product? Get in
              touch.
            </p>
            <div className="cta-band__actions">
              <Link to="/contact" className="btn btn--primary btn--large">
                Contact us <IconArrowRight size={17} />
              </Link>
              <Link to="/products" className="btn btn--large btn--ghost">
                See our products
              </Link>
            </div>
          </div>
        </Reveal>
      </div>
    </>
  );
}
