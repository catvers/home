import { Link } from 'react-router-dom';
import { SEO } from '../components/SEO';
import { Reveal } from '../components/Reveal';
import { EmptyState } from '../components/EmptyState';
import { IconCalendar } from '../components/icons';
import { getProducts, getUpdates } from '../data/store';
import { getPublishedUpdates } from '../data/updates';
import { formatDate } from '../lib/format';

function renderParagraphs(content: string) {
  return content
    .split(/\n\s*\n/)
    .map((p) => p.trim())
    .filter(Boolean);
}

export function Updates() {
  const updates = getPublishedUpdates(getUpdates());
  const products = getProducts();

  return (
    <>
      <SEO
        title="Updates"
        description="Launches, new features, milestones, and announcements from CatVers Studio — the changelog of everything the studio builds."
        path="/updates"
      />
      <div className="container page">
        <Reveal>
          <header className="page__header">
            <p className="section__eyebrow">Changelog</p>
            <h1 className="page__title">Updates</h1>
            <p className="page__lede">
              Product launches, new features, milestones, and announcements —
              the running story of CatVers Studio.
            </p>
          </header>
        </Reveal>

        {updates.length === 0 ? (
          <EmptyState
            title="No updates available"
            message="Nothing has been published here yet. Launches and announcements will appear in this timeline."
          />
        ) : (
          <ol className="timeline">
            {updates.map((u, i) => {
              const related = u.relatedProductSlug
                ? products.find((p) => p.slug === u.relatedProductSlug && p.published)
                : undefined;
              return (
                <Reveal as="li" key={u.id} delay={Math.min(i * 60, 240)}>
                  <article className="timeline__item">
                    <span className="timeline__dot" aria-hidden="true" />
                    <div className="timeline__card">
                      <p className="timeline__date">
                        <IconCalendar size={13} /> {formatDate(u.date)}
                      </p>
                      <h2 className="timeline__title">{u.title}</h2>
                      {u.image && (
                        <img
                          src={u.image}
                          alt=""
                          loading="lazy"
                          className="timeline__image"
                        />
                      )}
                      <div className="timeline__content">
                        {renderParagraphs(u.content).map((p, j) => (
                          <p key={j}>{p}</p>
                        ))}
                      </div>
                      <div className="timeline__foot">
                        {u.tags.length > 0 && (
                          <div className="tag-row" aria-label="Tags">
                            {u.tags.map((t) => (
                              <span key={t} className="tag">
                                {t}
                              </span>
                            ))}
                          </div>
                        )}
                        {related && (
                          <Link to={`/products/${related.slug}`} className="link-more">
                            View {related.name}
                          </Link>
                        )}
                      </div>
                    </div>
                  </article>
                </Reveal>
              );
            })}
          </ol>
        )}
      </div>
    </>
  );
}
