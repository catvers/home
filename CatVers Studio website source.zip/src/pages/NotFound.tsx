import { Link } from 'react-router-dom';
import { SEO } from '../components/SEO';
import { LogoMark, IconArrowRight } from '../components/icons';
import { getSite } from '../data/store';

export function NotFound() {
  const site = getSite();
  return (
    <>
      <SEO
        title="Page not found"
        description={`The page you are looking for does not exist on the ${site.name} website.`}
        path="/404"
        noIndex
      />
      <div className="container page">
        <div className="not-found">
          <LogoMark size={64} />
          <p className="not-found__code">404</p>
          <h1 className="not-found__title">This page doesn't exist.</h1>
          <p className="not-found__text">
            The link you followed may be broken, or the page may have moved.
          </p>
          <div className="not-found__actions">
            <Link to="/" className="btn btn--primary btn--large">
              Back to {site.name} <IconArrowRight size={17} />
            </Link>
            <Link to="/products" className="btn btn--large btn--ghost">
              Browse products
            </Link>
          </div>
        </div>
      </div>
    </>
  );
}
