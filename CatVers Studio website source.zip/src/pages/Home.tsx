import { Link } from 'react-router-dom';
import { SEO } from '../components/SEO';
import { Reveal } from '../components/Reveal';
import { ProductCard } from '../components/ProductCard';
import { CoverArt } from '../components/CoverArt';
import { StatusBadge } from '../components/StatusBadge';
import { CategoryIcon, IconArrowRight, IconCalendar } from '../components/icons';
import { categories } from '../data/site';
import { getProducts, getProjects, getSite, getUpdates } from '../data/store';
import {
  getFeaturedProducts,
  getProductsByStatus,
  getPublishedProducts,
} from '../data/products';
import { getPublishedUpdates } from '../data/updates';
import { formatDate } from '../lib/format';

function Hero() {
  const site = getSite();
  return (
    <section className="hero" aria-labelledby="hero-heading">
      <div className="hero__bg" aria-hidden="true">
        <span className="hero__orb hero__orb--1" />
        <span className="hero__orb hero__orb--2" />
        <span className="hero__orb hero__orb--3" />
        <span className="hero__grid" />
      </div>
      <div className="container hero__inner">
        <div className="hero__content">
          <p className="hero__eyebrow">
            <span className="pulse-dot" aria-hidden="true" />
            Independent software studio
          </p>
          <h1 id="hero-heading" className="hero__title">
            Building useful digital products with{' '}
            <span className="gradient-text">AI and technology</span>.
          </h1>
          <p className="hero__subtitle">{site.description}</p>
          <div className="hero__actions">
            <Link to="/products" className="btn btn--primary btn--large">
              Explore Products <IconArrowRight size={17} />
            </Link>
            <Link to="/about" className="btn btn--large btn--ghost">
              About {site.name}
            </Link>
          </div>
        </div>
        <div className="hero__visual" aria-hidden="true">
          <div className="hero__cards">
            <div className="hero__card hero__card--1">
              <span className="hero__card-icon">{'{}'}</span>
              <span className="hero__card-label">Build</span>
            </div>
            <div className="hero__card hero__card--2">
              <span className="hero__card-icon">Aa</span>
              <span className="hero__card-label">Design</span>
            </div>
            <div className="hero__card hero__card--3">
              <span className="hero__card-icon">&#9654;</span>
              <span className="hero__card-label">Ship</span>
            </div>
            <div className="hero__card hero__card--main">
              <span className="hero__card-title">My Expenses</span>
              <span className="hero__card-sub">In development</span>
              <span className="hero__progress">
                <span className="hero__progress-bar" />
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Categories() {
  return (
    <section className="section" aria-labelledby="categories-heading">
      <div className="container">
        <Reveal>
          <p className="section__eyebrow">What we build</p>
          <h2 id="categories-heading" className="section__title">
            Simple tools for everyday life
          </h2>
          <p className="section__subtitle">
            Every CatVers Studio product starts from a real, everyday problem —
            and stays focused on solving it well.
          </p>
        </Reveal>
        <ul className="category-grid">
          {categories.map((cat, i) => (
            <Reveal as="li" key={cat.name} delay={Math.min(i * 60, 300)}>
              <div className="category-card">
                <span className="category-card__icon" aria-hidden="true">
                  <CategoryIcon name={cat.icon} />
                </span>
                <h3 className="category-card__name">{cat.name}</h3>
                <p className="category-card__desc">{cat.description}</p>
              </div>
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  );
}

function Featured() {
  const featured = getFeaturedProducts(getProducts());
  if (featured.length === 0) return null;
  return (
    <section className="section section--alt" aria-labelledby="featured-heading">
      <div className="container">
        <Reveal>
          <div className="section__head">
            <div>
              <p className="section__eyebrow">Featured</p>
              <h2 id="featured-heading" className="section__title">
                Products we're proud of
              </h2>
            </div>
            <Link to="/products" className="link-more">
              All products <IconArrowRight size={15} />
            </Link>
          </div>
        </Reveal>
        <div className="card-grid">
          {featured.map((p, i) => (
            <Reveal key={p.id} delay={Math.min(i * 80, 240)}>
              <ProductCard product={p} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function RecentlyPublished() {
  const recent = getPublishedProducts(getProducts()).filter(
    (p) => p.status === 'published',
  );
  if (recent.length === 0) return null;
  return (
    <section className="section" aria-labelledby="recent-heading">
      <div className="container">
        <Reveal>
          <p className="section__eyebrow">Recently published</p>
          <h2 id="recent-heading" className="section__title">
            Fresh out of the studio
          </h2>
          <p className="section__subtitle">
            The latest products and websites launched by CatVers Studio.
          </p>
        </Reveal>
        <ul className="recent-list">
          {recent.slice(0, 4).map((p, i) => {
            const launched = formatDate(p.launchDate);
            return (
              <Reveal as="li" key={p.id} delay={Math.min(i * 60, 240)}>
                <Link to={`/products/${p.slug}`} className="recent-item">
                  <div className="recent-item__media">
                    {p.coverImage ? (
                      <img src={p.coverImage} alt="" loading="lazy" />
                    ) : (
                      <CoverArt accent={p.accent} name={p.name} />
                    )}
                  </div>
                  <div className="recent-item__body">
                    <div className="recent-item__meta">
                      <StatusBadge status={p.status} />
                      {launched && (
                        <span className="recent-item__date">
                          <IconCalendar size={13} /> {launched}
                        </span>
                      )}
                    </div>
                    <h3 className="recent-item__name">{p.name}</h3>
                    <p className="recent-item__desc">{p.shortDescription}</p>
                    <p className="recent-item__tags">
                      {p.category} · {p.platform}
                    </p>
                  </div>
                  <span className="recent-item__arrow" aria-hidden="true">
                    <IconArrowRight size={18} />
                  </span>
                </Link>
              </Reveal>
            );
          })}
        </ul>
      </div>
    </section>
  );
}

function CurrentlyBuilding() {
  const building = getProductsByStatus(getProducts(), ['in-development', 'coming-soon']);
  const projectBuilding = getProjects()
    .filter((p) => p.published && (p.status === 'in-development' || p.status === 'experimental'))
    .slice(0, 3);
  if (building.length === 0 && projectBuilding.length === 0) return null;
  return (
    <section className="section section--alt" aria-labelledby="building-heading">
      <div className="container">
        <Reveal>
          <p className="section__eyebrow">Currently building</p>
          <h2 id="building-heading" className="section__title">
            Work in progress
          </h2>
          <p className="section__subtitle">
            A look at what's being designed, coded, and tested right now.
          </p>
        </Reveal>
        <div className="card-grid">
          {building.map((p, i) => {
            const updated = formatDate(p.lastUpdated);
            return (
              <Reveal key={p.id} delay={Math.min(i * 80, 240)}>
                <Link to={`/products/${p.slug}`} className="building-card">
                  <StatusBadge status={p.status} />
                  <h3 className="building-card__name">{p.name}</h3>
                  <p className="building-card__desc">{p.shortDescription}</p>
                  <p className="building-card__meta">
                    {p.category} · {p.platform}
                    {updated && ` · Updated ${updated}`}
                  </p>
                </Link>
              </Reveal>
            );
          })}
          {projectBuilding.map((p, i) => (
            <Reveal key={p.id} delay={Math.min((building.length + i) * 80, 320)}>
              <div className="building-card">
                <StatusBadge status={p.status} />
                <h3 className="building-card__name">{p.name}</h3>
                <p className="building-card__desc">{p.description}</p>
                <p className="building-card__meta">{p.category}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function UpdatesTeaser() {
  const updates = getPublishedUpdates(getUpdates()).slice(0, 3);
  if (updates.length === 0) return null;
  const products = getProducts();
  return (
    <section className="section" aria-labelledby="updates-heading">
      <div className="container">
        <Reveal>
          <div className="section__head">
            <div>
              <p className="section__eyebrow">Updates</p>
              <h2 id="updates-heading" className="section__title">
                News from the studio
              </h2>
            </div>
            <Link to="/updates" className="link-more">
              All updates <IconArrowRight size={15} />
            </Link>
          </div>
        </Reveal>
        <div className="card-grid card-grid--3">
          {updates.map((u, i) => {
            const related = u.relatedProductSlug
              ? products.find((p) => p.slug === u.relatedProductSlug)
              : undefined;
            return (
              <Reveal key={u.id} delay={Math.min(i * 80, 240)}>
                <article className="update-card">
                  <p className="update-card__date">
                    <IconCalendar size={13} /> {formatDate(u.date)}
                  </p>
                  <h3 className="update-card__title">{u.title}</h3>
                  <p className="update-card__excerpt">{u.excerpt}</p>
                  {related && (
                    <Link
                      to={`/products/${related.slug}`}
                      className="update-card__related"
                    >
                      Related: {related.name}
                    </Link>
                  )}
                </article>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function CtaBand() {
  const site = getSite();
  return (
    <section className="section" aria-labelledby="cta-heading">
      <div className="container">
        <Reveal>
          <div className="cta-band">
            <h2 id="cta-heading" className="cta-band__title">
              Let's build something useful.
            </h2>
            <p className="cta-band__text">
              Have an idea, feedback, or a question about a {site.name} product?
              We'd love to hear from you.
            </p>
            <div className="cta-band__actions">
              <Link to="/contact" className="btn btn--primary btn--large">
                Get in touch <IconArrowRight size={17} />
              </Link>
              <Link to="/about" className="btn btn--large btn--ghost">
                About the studio
              </Link>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export function Home() {
  const site = getSite();
  return (
    <>
      <SEO
        title={site.name}
        description={`${site.tagline} ${site.description}`}
        path="/"
      />
      <Hero />
      <Categories />
      <Featured />
      <RecentlyPublished />
      <CurrentlyBuilding />
      <UpdatesTeaser />
      <CtaBand />
    </>
  );
}
