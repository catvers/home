/**
 * CatVers Studio — shared content types.
 *
 * The public site renders exclusively from these data structures.
 * To add a product, edit `src/data/products.ts` — every card, list,
 * search index, filter and product page is generated from that file.
 */

export type ProductStatus =
  | 'published'
  | 'in-development'
  | 'coming-soon'
  | 'experimental'
  | 'archived';

export const PRODUCT_STATUSES: ProductStatus[] = [
  'published',
  'in-development',
  'coming-soon',
  'experimental',
  'archived',
];

export const STATUS_LABELS: Record<ProductStatus, string> = {
  published: 'Published',
  'in-development': 'In Development',
  'coming-soon': 'Coming Soon',
  experimental: 'Experimental',
  archived: 'Archived',
};

export interface Product {
  id: string;
  slug: string;
  name: string;
  shortDescription: string;
  longDescription: string;
  category: string;
  /** e.g. "Web", "Android", "Web · Android" */
  platform: string;
  status: ProductStatus;
  /** URL or path to a logo image. Empty string = generated monogram is used. */
  logo: string;
  /** URL or path to a cover image. Empty string = generated cover art is used. */
  coverImage: string;
  screenshots: string[];
  websiteUrl: string | null;
  downloadUrl: string | null;
  sourceUrl: string | null;
  /** ISO date (YYYY-MM-DD) or null when not announced */
  launchDate: string | null;
  lastUpdated: string | null;
  features: string[];
  tags: string[];
  featured: boolean;
  /** Hidden from the public site when false */
  published: boolean;
  /** Gradient key used for generated cover art */
  accent: string;
}

export interface Project {
  id: string;
  slug: string;
  name: string;
  description: string;
  status: ProductStatus;
  category: string;
  image: string;
  date: string | null;
  link: string | null;
  published: boolean;
  accent: string;
}

export interface UpdateEntry {
  id: string;
  slug: string;
  title: string;
  /** ISO date (YYYY-MM-DD) */
  date: string;
  excerpt: string;
  /** Paragraphs separated by blank lines */
  content: string;
  relatedProductSlug: string | null;
  image: string | null;
  tags: string[];
  published: boolean;
}

export interface CategoryInfo {
  name: string;
  description: string;
  /** key into the icon set */
  icon: string;
}

export interface SiteInfo {
  name: string;
  tagline: string;
  description: string;
  manager: string;
  managerRole: string;
  managerBio: string;
  email: string;
  /** Canonical site URL. Replace with the real domain when deploying. */
  url: string;
}
