import { Suspense, lazy, useEffect } from 'react';
import { BrowserRouter, Route, Routes, useLocation } from 'react-router-dom';
import { Layout } from './components/Layout';
import { useTheme } from './hooks/useTheme';
import { Home } from './pages/Home';
import { About } from './pages/About';
import { Products } from './pages/Products';
import { ProductDetail } from './pages/ProductDetail';
import { Projects } from './pages/Projects';
import { Updates } from './pages/Updates';
import { Contact } from './pages/Contact';
import { Privacy } from './pages/Privacy';
import { NotFound } from './pages/NotFound';
import './styles/base.css';
import './styles/components.css';
import './styles/pages.css';
import './styles/admin.css';

const Admin = lazy(() =>
  import('./admin/Admin').then((m) => ({ default: m.Admin })),
);

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  }, [pathname]);
  return null;
}

function AdminLoading() {
  return (
    <div className="container page">
      <p className="loading-text" role="status">
        Loading admin…
      </p>
    </div>
  );
}

function SiteRoutes() {
  const { theme, toggleTheme } = useTheme();
  return (
    <>
      <ScrollToTop />
      <Routes>
        <Route
          path="/admin"
          element={
            <Suspense fallback={<AdminLoading />}>
              <Admin />
            </Suspense>
          }
        />
        <Route
          path="*"
          element={
            <Layout theme={theme} onToggleTheme={toggleTheme}>
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/about" element={<About />} />
                <Route path="/products" element={<Products />} />
                <Route path="/products/:slug" element={<ProductDetail />} />
                <Route path="/projects" element={<Projects />} />
                <Route path="/updates" element={<Updates />} />
                <Route path="/contact" element={<Contact />} />
                <Route path="/privacy" element={<Privacy />} />
                <Route path="/404" element={<NotFound />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </Layout>
          }
        />
      </Routes>
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <SiteRoutes />
    </BrowserRouter>
  );
}
