# Admin dashboard — architecture notes

Route: `/admin` (not linked from public navigation; open it directly).
`robots.txt` asks search engines not to index it, and the page sets `noindex`.

## How it works today

- Static source of truth: `src/data/products.ts`, `src/data/projects.ts`,
  `src/data/updates.ts`, `src/data/site.ts`.
- Public pages never import those files directly — they use the getters in
  `src/data/store.ts` (`getProducts()`, `getProjects()`, `getUpdates()`,
  `getSite()`).
- When you save in `/admin`, the whole content snapshot is written to
  `localStorage` (`catvers_admin_v1`). The getters merge it over the static
  files, so edits preview instantly without a rebuild.
- **Nothing is sent to a server.** There is no login; anyone opening `/admin`
  in that browser can edit the preview. Do not treat this as a secure system.

## Publishing admin edits

1. In `/admin`, press **Export JSON** → downloads `catvers-content.json`.
2. Copy the arrays back into `src/data/products.ts`, `src/data/projects.ts`,
   `src/data/updates.ts` and the object into `src/data/site.ts`.
3. `npm run build` and redeploy `dist/`.

**Import JSON** loads a previously exported file back into the local preview.
**Reset to source files** clears the localStorage overrides.

## Connecting a real backend later

The data layer is already isolated: every page reads through
`src/data/store.ts`. To use a backend:

1. Replace the getters in `src/data/store.ts` with `fetch()` calls to your API
   (keep the same return types in `src/types.ts`).
2. Replace `writeOverrides` in `/admin` with authenticated `POST/PUT/DELETE`
   calls. Add real authentication (never ship the current no-login admin
   against a shared backend).
3. Keep the static files as fallback/seed data.

## Contact form

The contact form on `/contact` currently opens the visitor's email app with a
prefilled `mailto:` link — no backend needed. To use a form service instead,
replace `handleSubmit` in `src/pages/Contact.tsx` with a `POST` to your
endpoint (Formspree, Web3Forms, or your own API); the fields are already named
`name`, `email`, `subject`, `message`.
