import { useRef, type ReactNode } from 'react';

/** Small reusable form controls for the admin dashboard. */

export function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <label className="admin-field">
      <span className="admin-field__label">{label}</span>
      {children}
      {hint && <span className="admin-field__hint">{hint}</span>}
    </label>
  );
}

export function TextInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input type="text" className="admin-input" {...props} />;
}

export function TextArea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className="admin-input admin-textarea" rows={4} {...props} />;
}

export function SelectInput(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select className="admin-input" {...props} />;
}

export function CheckInput({
  label,
  ...props
}: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="admin-check">
      <input type="checkbox" {...props} />
      <span>{label}</span>
    </label>
  );
}

/**
 * Text input with an optional image-file picker. When a file is chosen it is
 * read as a data URL and written into the text field, so small logos and
 * covers can be embedded without any image hosting.
 */
export function ImageInput({
  value,
  onChange,
  label,
}: {
  value: string;
  onChange: (v: string) => void;
  label: string;
}) {
  const fileRef = useRef<HTMLInputElement>(null);

  const onFile = (file: File | undefined) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') onChange(reader.result);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="admin-image">
      <Field label={label} hint="Paste an image URL, or pick a file to embed it (kept small — large files bloat the saved data).">
        <TextInput
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="https://… or leave empty for generated art"
        />
      </Field>
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="visually-hidden"
        aria-label={`${label} — choose image file`}
        onChange={(e) => onFile(e.target.files?.[0])}
      />
      <div className="admin-image__row">
        <button
          type="button"
          className="btn btn--small btn--ghost"
          onClick={() => fileRef.current?.click()}
        >
          Choose image file…
        </button>
        {value && (
          <button
            type="button"
            className="btn btn--small btn--ghost"
            onClick={() => onChange('')}
          >
            Clear
          </button>
        )}
      </div>
      {value && (
        <img src={value} alt="Preview" className="admin-image__preview" />
      )}
    </div>
  );
}

/** Textarea where each line becomes one list item (features, tags, screenshots). */
export function ListArea({
  label,
  values,
  onChange,
  placeholder,
  hint,
}: {
  label: string;
  values: string[];
  onChange: (v: string[]) => void;
  placeholder?: string;
  hint?: string;
}) {
  return (
    <Field label={label} hint={hint ?? 'One item per line.'}>
      <TextArea
        value={values.join('\n')}
        onChange={(e) =>
          onChange(
            e.target.value
              .split('\n')
              .map((s) => s.trim())
              .filter(Boolean),
          )
        }
        placeholder={placeholder}
      />
    </Field>
  );
}
