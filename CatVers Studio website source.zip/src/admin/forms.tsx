import type { Product, Project, SiteInfo, UpdateEntry } from '../types';
import { PRODUCT_STATUSES, STATUS_LABELS } from '../types';
import { categories } from '../data/site';
import {
  CheckInput,
  Field,
  ImageInput,
  ListArea,
  SelectInput,
  TextArea,
  TextInput,
} from './fields';

/* ------------------------------------------------------------------ */
/* Products                                                            */
/* ------------------------------------------------------------------ */

const ACCENTS = ['indigo', 'emerald', 'amber', 'violet', 'sky', 'rose', 'teal'];

export function ProductForm({
  product,
  onChange,
}: {
  product: Product;
  onChange: (p: Product) => void;
}) {
  const set = <K extends keyof Product>(key: K, value: Product[K]) =>
    onChange({ ...product, [key]: value });

  return (
    <div className="admin-form-grid">
      <Field label="Product name">
        <TextInput value={product.name} onChange={(e) => set('name', e.target.value)} required />
      </Field>
      <Field label="URL slug" hint="Lowercase, URL-safe. Used in /products/<slug>.">
        <TextInput value={product.slug} onChange={(e) => set('slug', e.target.value)} required />
      </Field>
      <Field label="Short description">
        <TextInput
          value={product.shortDescription}
          onChange={(e) => set('shortDescription', e.target.value)}
        />
      </Field>
      <Field label="Category">
        <SelectInput value={product.category} onChange={(e) => set('category', e.target.value)}>
          {categories.map((c) => (
            <option key={c.name} value={c.name}>
              {c.name}
            </option>
          ))}
        </SelectInput>
      </Field>
      <Field label="Platform" hint='e.g. "Web", "Android", "Web · Android".'>
        <TextInput value={product.platform} onChange={(e) => set('platform', e.target.value)} />
      </Field>
      <Field label="Status">
        <SelectInput
          value={product.status}
          onChange={(e) => set('status', e.target.value as Product['status'])}
        >
          {PRODUCT_STATUSES.map((s) => (
            <option key={s} value={s}>
              {STATUS_LABELS[s]}
            </option>
          ))}
        </SelectInput>
      </Field>
      <div className="admin-form-grid__full">
        <Field label="Long description">
          <TextArea value={product.longDescription} onChange={(e) => set('longDescription', e.target.value)} rows={5} />
        </Field>
      </div>
      <div className="admin-form-grid__full">
        <ListArea label="Features" values={product.features} onChange={(v) => set('features', v)} placeholder={'Calculates age in years, months, and days\nWorks on phones, tablets, and desktops'} />
      </div>
      <div className="admin-form-grid__full">
        <ListArea label="Tags" values={product.tags} onChange={(v) => set('tags', v)} placeholder={'utility\nweb'} />
      </div>
      <ImageInput label="Logo image" value={product.logo} onChange={(v) => set('logo', v)} />
      <ImageInput label="Cover image" value={product.coverImage} onChange={(v) => set('coverImage', v)} />
      <div className="admin-form-grid__full">
        <ListArea
          label="Screenshots"
          values={product.screenshots}
          onChange={(v) => set('screenshots', v)}
          hint="One image URL per line. Leave empty if there are no screenshots yet."
        />
      </div>
      <Field label="Website URL" hint="Leave empty until a real link exists — the button stays hidden.">
        <TextInput value={product.websiteUrl ?? ''} onChange={(e) => set('websiteUrl', e.target.value.trim() || null)} placeholder="https://…" inputMode="url" />
      </Field>
      <Field label="Download URL">
        <TextInput value={product.downloadUrl ?? ''} onChange={(e) => set('downloadUrl', e.target.value.trim() || null)} placeholder="https://…" inputMode="url" />
      </Field>
      <Field label="Source code URL (optional)">
        <TextInput value={product.sourceUrl ?? ''} onChange={(e) => set('sourceUrl', e.target.value.trim() || null)} placeholder="https://…" inputMode="url" />
      </Field>
      <Field label="Cover art accent">
        <SelectInput value={product.accent} onChange={(e) => set('accent', e.target.value)}>
          {ACCENTS.map((a) => (
            <option key={a} value={a}>
              {a}
            </option>
          ))}
        </SelectInput>
      </Field>
      <Field label="Launch date" hint="Leave empty if not announced.">
        <input
          type="date"
          className="admin-input"
          value={product.launchDate ?? ''}
          onChange={(e) => set('launchDate', e.target.value || null)}
        />
      </Field>
      <Field label="Last updated">
        <input
          type="date"
          className="admin-input"
          value={product.lastUpdated ?? ''}
          onChange={(e) => set('lastUpdated', e.target.value || null)}
        />
      </Field>
      <div className="admin-checks">
        <CheckInput label="Featured on home page" checked={product.featured} onChange={(e) => set('featured', e.target.checked)} />
        <CheckInput label="Visible on public site" checked={product.published} onChange={(e) => set('published', e.target.checked)} />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Projects                                                            */
/* ------------------------------------------------------------------ */

export function ProjectForm({
  project,
  onChange,
}: {
  project: Project;
  onChange: (p: Project) => void;
}) {
  const set = <K extends keyof Project>(key: K, value: Project[K]) =>
    onChange({ ...project, [key]: value });

  return (
    <div className="admin-form-grid">
      <Field label="Project name">
        <TextInput value={project.name} onChange={(e) => set('name', e.target.value)} required />
      </Field>
      <Field label="URL slug">
        <TextInput value={project.slug} onChange={(e) => set('slug', e.target.value)} required />
      </Field>
      <div className="admin-form-grid__full">
        <Field label="Description">
          <TextArea value={project.description} onChange={(e) => set('description', e.target.value)} rows={4} />
        </Field>
      </div>
      <Field label="Status">
        <SelectInput value={project.status} onChange={(e) => set('status', e.target.value as Project['status'])}>
          {PRODUCT_STATUSES.map((s) => (
            <option key={s} value={s}>
              {STATUS_LABELS[s]}
            </option>
          ))}
        </SelectInput>
      </Field>
      <Field label="Category">
        <TextInput value={project.category} onChange={(e) => set('category', e.target.value)} placeholder="Website, Experimental…" />
      </Field>
      <Field label="Date" hint="Leave empty if not applicable.">
        <input
          type="date"
          className="admin-input"
          value={project.date ?? ''}
          onChange={(e) => set('date', e.target.value || null)}
        />
      </Field>
      <Field label="Link URL" hint="Leave empty until a real link exists.">
        <TextInput value={project.link ?? ''} onChange={(e) => set('link', e.target.value.trim() || null)} placeholder="https://…" inputMode="url" />
      </Field>
      <Field label="Cover art accent">
        <SelectInput value={project.accent} onChange={(e) => set('accent', e.target.value)}>
          {ACCENTS.map((a) => (
            <option key={a} value={a}>
              {a}
            </option>
          ))}
        </SelectInput>
      </Field>
      <ImageInput label="Image" value={project.image} onChange={(v) => set('image', v)} />
      <div className="admin-checks">
        <CheckInput label="Visible on public site" checked={project.published} onChange={(e) => set('published', e.target.checked)} />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Updates                                                             */
/* ------------------------------------------------------------------ */

export function UpdateForm({
  update,
  onChange,
  productSlugs,
}: {
  update: UpdateEntry;
  onChange: (u: UpdateEntry) => void;
  productSlugs: string[];
}) {
  const set = <K extends keyof UpdateEntry>(key: K, value: UpdateEntry[K]) =>
    onChange({ ...update, [key]: value });

  return (
    <div className="admin-form-grid">
      <div className="admin-form-grid__full">
        <Field label="Title">
          <TextInput value={update.title} onChange={(e) => set('title', e.target.value)} required />
        </Field>
      </div>
      <Field label="URL slug">
        <TextInput value={update.slug} onChange={(e) => set('slug', e.target.value)} required />
      </Field>
      <Field label="Date">
        <input
          type="date"
          className="admin-input"
          value={update.date}
          onChange={(e) => set('date', e.target.value)}
          required
        />
      </Field>
      <div className="admin-form-grid__full">
        <Field label="Short excerpt">
          <TextInput value={update.excerpt} onChange={(e) => set('excerpt', e.target.value)} />
        </Field>
      </div>
      <div className="admin-form-grid__full">
        <Field label="Content" hint="Separate paragraphs with a blank line.">
          <TextArea value={update.content} onChange={(e) => set('content', e.target.value)} rows={8} />
        </Field>
      </div>
      <Field label="Related product">
        <SelectInput
          value={update.relatedProductSlug ?? ''}
          onChange={(e) => set('relatedProductSlug', e.target.value || null)}
        >
          <option value="">None</option>
          {productSlugs.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </SelectInput>
      </Field>
      <ImageInput label="Image (optional)" value={update.image ?? ''} onChange={(v) => set('image', v || null)} />
      <div className="admin-form-grid__full">
        <ListArea label="Tags" values={update.tags} onChange={(v) => set('tags', v)} />
      </div>
      <div className="admin-checks">
        <CheckInput label="Visible on public site" checked={update.published} onChange={(e) => set('published', e.target.checked)} />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Site info                                                           */
/* ------------------------------------------------------------------ */

export function SiteForm({
  site,
  onChange,
}: {
  site: SiteInfo;
  onChange: (s: SiteInfo) => void;
}) {
  const set = <K extends keyof SiteInfo>(key: K, value: SiteInfo[K]) =>
    onChange({ ...site, [key]: value });

  return (
    <div className="admin-form-grid">
      <Field label="Studio name">
        <TextInput value={site.name} onChange={(e) => set('name', e.target.value)} />
      </Field>
      <Field label="Tagline">
        <TextInput value={site.tagline} onChange={(e) => set('tagline', e.target.value)} />
      </Field>
      <div className="admin-form-grid__full">
        <Field label="Description">
          <TextArea value={site.description} onChange={(e) => set('description', e.target.value)} rows={3} />
        </Field>
      </div>
      <Field label="Manager name">
        <TextInput value={site.manager} onChange={(e) => set('manager', e.target.value)} />
      </Field>
      <Field label="Manager role">
        <TextInput value={site.managerRole} onChange={(e) => set('managerRole', e.target.value)} />
      </Field>
      <div className="admin-form-grid__full">
        <Field label="Manager bio" hint="Only include information that is actually true.">
          <TextArea value={site.managerBio} onChange={(e) => set('managerBio', e.target.value)} rows={4} />
        </Field>
      </div>
      <Field label="Contact email">
        <TextInput value={site.email} onChange={(e) => set('email', e.target.value)} inputMode="email" />
      </Field>
      <Field label="Canonical site URL" hint="Used for SEO canonical links and social previews.">
        <TextInput value={site.url} onChange={(e) => set('url', e.target.value)} inputMode="url" />
      </Field>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Factories for new items                                             */
/* ------------------------------------------------------------------ */

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
}

export function newProduct(): Product {
  return {
    id: `product-${Date.now()}`,
    slug: '',
    name: '',
    shortDescription: '',
    longDescription: '',
    category: categories[0]?.name ?? 'Utilities',
    platform: 'Web',
    status: 'coming-soon',
    logo: '',
    coverImage: '',
    screenshots: [],
    websiteUrl: null,
    downloadUrl: null,
    sourceUrl: null,
    launchDate: null,
    lastUpdated: null,
    features: [],
    tags: [],
    featured: false,
    published: true,
    accent: 'indigo',
  };
}

export function newProject(): Project {
  return {
    id: `project-${Date.now()}`,
    slug: '',
    name: '',
    description: '',
    status: 'experimental',
    category: 'Experimental',
    image: '',
    date: null,
    link: null,
    published: true,
    accent: 'violet',
  };
}

export function newUpdate(): UpdateEntry {
  return {
    id: `update-${Date.now()}`,
    slug: '',
    title: '',
    date: new Date().toISOString().slice(0, 10),
    excerpt: '',
    content: '',
    relatedProductSlug: null,
    image: null,
    tags: [],
    published: true,
  };
}
