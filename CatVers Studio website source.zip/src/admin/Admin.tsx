import { useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { SEO } from '../components/SEO';
import { StatusBadge } from '../components/StatusBadge';
import {
  IconArrowLeft,
  IconInfo,
  IconPencil,
  IconPlus,
  IconTrash,
  LogoMark,
} from '../components/icons';
import type { ContentSnapshot } from '../data/store';
import {
  clearOverrides,
  getContent,
  hasOverrides,
  writeOverrides,
} from '../data/store';
import type { Product, Project, UpdateEntry } from '../types';
import {
  ProductForm,
  ProjectForm,
  SiteForm,
  UpdateForm,
  newProduct,
  newProject,
  newUpdate,
  slugify,
} from './forms';

/**
 * Admin dashboard (route: /admin).
 *
 * IMPORTANT — read before using:
 * - This page has NO login and NO server. Anyone who opens /admin in this
 *   browser can change the preview. It is a content-editing helper, not a
 *   secure admin system.
 * - Changes are stored in this browser's localStorage only. They let you
 *   preview edits instantly, but they are NOT published to the live site.
 * - To publish: press "Export JSON", then copy the exported data back into
 *   src/data/products.ts, src/data/projects.ts, src/data/updates.ts and
 *   src/data/site.ts, and rebuild the site.
 * - The /admin route is intentionally NOT linked from the public navigation.
 */

type Tab = 'products' | 'projects' | 'updates' | 'site';

type EditorState =
  | { kind: 'product'; item: Product }
  | { kind: 'project'; item: Project }
  | { kind: 'update'; item: UpdateEntry }
  | null;

const TABS: { id: Tab; label: string }[] = [
  { id: 'products', label: 'Products' },
  { id: 'projects', label: 'Projects' },
  { id: 'updates', label: 'Updates' },
  { id: 'site', label: 'Site info' },
];

function ensureSlug(item: { slug: string; name?: string; title?: string }) {
  if (!item.slug.trim()) {
    item.slug = slugify(item.name || item.title || 'untitled');
  }
}

export function Admin() {
  const [content, setContent] = useState<ContentSnapshot>(() => getContent());
  const [tab, setTab] = useState<Tab>('products');
  const [editor, setEditor] = useState<EditorState>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [previewingEdits, setPreviewingEdits] = useState(() => hasOverrides());
  const importRef = useRef<HTMLInputElement>(null);

  const persist = (next: ContentSnapshot, message: string) => {
    try {
      writeOverrides(next);
      setContent(next);
      setPreviewingEdits(true);
      setNotice(message);
      window.setTimeout(() => setNotice(null), 4000);
    } catch {
      setNotice('Could not save: browser storage is unavailable or full.');
    }
  };

  /* ----- product handlers ----- */
  const saveProduct = (item: Product) => {
    ensureSlug(item);
    const products = content.products.some((p) => p.id === item.id)
      ? content.products.map((p) => (p.id === item.id ? item : p))
      : [...content.products, item];
    persist({ ...content, products }, `Saved “${item.name || item.slug}”. Preview updated — export JSON to publish.`);
    setEditor(null);
  };

  const deleteProduct = (item: Product) => {
    if (!window.confirm(`Delete “${item.name}” from the preview?`)) return;
    persist(
      { ...content, products: content.products.filter((p) => p.id !== item.id) },
      `Deleted “${item.name}”.`,
    );
  };

  /* ----- project handlers ----- */
  const saveProject = (item: Project) => {
    ensureSlug(item);
    const projects = content.projects.some((p) => p.id === item.id)
      ? content.projects.map((p) => (p.id === item.id ? item : p))
      : [...content.projects, item];
    persist({ ...content, projects }, `Saved “${item.name || item.slug}”. Preview updated — export JSON to publish.`);
    setEditor(null);
  };

  const deleteProject = (item: Project) => {
    if (!window.confirm(`Delete “${item.name}” from the preview?`)) return;
    persist(
      { ...content, projects: content.projects.filter((p) => p.id !== item.id) },
      `Deleted “${item.name}”.`,
    );
  };

  /* ----- update handlers ----- */
  const saveUpdate = (item: UpdateEntry) => {
    ensureSlug(item);
    const updates = content.updates.some((u) => u.id === item.id)
      ? content.updates.map((u) => (u.id === item.id ? item : u))
      : [item, ...content.updates];
    persist({ ...content, updates }, `Saved “${item.title || item.slug}”. Preview updated — export JSON to publish.`);
    setEditor(null);
  };

  const deleteUpdate = (item: UpdateEntry) => {
    if (!window.confirm(`Delete “${item.title}” from the preview?`)) return;
    persist(
      { ...content, updates: content.updates.filter((u) => u.id !== item.id) },
      `Deleted “${item.title}”.`,
    );
  };

  /* ----- site handler ----- */
  const saveSite = () => {
    persist(content, 'Site info saved. Preview updated — export JSON to publish.');
  };

  /* ----- export / import / reset ----- */
  const exportJson = () => {
    const blob = new Blob([JSON.stringify(content, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'catvers-content.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const importJson = (file: File | undefined) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result)) as Partial<ContentSnapshot>;
        if (!Array.isArray(parsed.products) || !Array.isArray(parsed.projects) || !Array.isArray(parsed.updates)) {
          throw new Error('bad shape');
        }
        const next: ContentSnapshot = {
          products: parsed.products,
          projects: parsed.projects,
          updates: parsed.updates,
          site: parsed.site ?? content.site,
        };
        writeOverrides(next);
        setContent(next);
        setPreviewingEdits(true);
        setNotice('Imported JSON. Preview updated.');
      } catch {
        setNotice('Import failed: the file is not a valid CatVers content export.');
      }
    };
    reader.readAsText(file);
  };

  const resetAll = () => {
    if (!window.confirm('Discard all local admin edits and go back to the source files?')) return;
    clearOverrides();
    setContent(getContent());
    setPreviewingEdits(false);
    setEditor(null);
    setNotice('Local edits discarded. Showing content from the source files.');
  };

  const productSlugs = content.products.map((p) => p.slug).filter(Boolean);

  return (
    <>
      <SEO title="Admin" description="CatVers Studio content manager." path="/admin" noIndex />
      <div className="admin">
        <div className="container">
          <div className="admin__topbar">
            <Link to="/" className="brand" aria-label="Back to website">
              <LogoMark size={28} />
              <span className="brand__wordmark">
                CatVers <span className="brand__wordmark-accent">Studio</span>
              </span>
            </Link>
            <span className="admin__badge">Admin</span>
          </div>

          <div className="admin-notice" role="note">
            <IconInfo size={18} />
            <div>
              <strong>Local preview only — not a secure admin system.</strong>
              <p>
                There is no login and no server here. Changes are stored in{' '}
                <em>this browser only</em> so you can preview edits instantly.
                To publish them, press <strong>Export JSON</strong> and copy the
                data back into <code>src/data/*.ts</code>, then rebuild the
                site. This page is intentionally not linked from the public
                navigation.
              </p>
            </div>
          </div>

          <div className="admin__statusbar">
            <span className={`admin__status${previewingEdits ? ' is-edited' : ''}`}>
              <span className="status-dot" aria-hidden="true" />
              {previewingEdits
                ? 'Previewing local edits (not published)'
                : 'Showing content from source files'}
            </span>
            <div className="admin__tools">
              <button type="button" className="btn btn--small btn--ghost" onClick={exportJson}>
                Export JSON
              </button>
              <button
                type="button"
                className="btn btn--small btn--ghost"
                onClick={() => importRef.current?.click()}
              >
                Import JSON
              </button>
              <input
                ref={importRef}
                type="file"
                accept="application/json,.json"
                className="visually-hidden"
                aria-label="Import content JSON"
                onChange={(e) => {
                  importJson(e.target.files?.[0]);
                  e.target.value = '';
                }}
              />
              <button type="button" className="btn btn--small btn--danger-ghost" onClick={resetAll}>
                Reset to source files
              </button>
            </div>
          </div>

          {notice && (
            <p className="admin__notice-msg" role="status">
              {notice}
            </p>
          )}

          {editor ? (
            <section className="admin__editor" aria-label="Edit item">
              <button
                type="button"
                className="back-link"
                onClick={() => setEditor(null)}
              >
                <IconArrowLeft size={16} /> Back to list
              </button>
              <h1 className="admin__title">
                {editor.kind === 'product' &&
                  (content.products.some((p) => p.id === editor.item.id) ? 'Edit product' : 'New product')}
                {editor.kind === 'project' &&
                  (content.projects.some((p) => p.id === editor.item.id) ? 'Edit project' : 'New project')}
                {editor.kind === 'update' &&
                  (content.updates.some((u) => u.id === editor.item.id) ? 'Edit update' : 'New update')}
              </h1>
              {editor.kind === 'product' && (
                <AdminFormShell
                  onSave={() => saveProduct(editor.item)}
                  onCancel={() => setEditor(null)}
                >
                  <ProductForm product={editor.item} onChange={(item) => setEditor({ kind: 'product', item })} />
                </AdminFormShell>
              )}
              {editor.kind === 'project' && (
                <AdminFormShell
                  onSave={() => saveProject(editor.item)}
                  onCancel={() => setEditor(null)}
                >
                  <ProjectForm project={editor.item} onChange={(item) => setEditor({ kind: 'project', item })} />
                </AdminFormShell>
              )}
              {editor.kind === 'update' && (
                <AdminFormShell
                  onSave={() => saveUpdate(editor.item)}
                  onCancel={() => setEditor(null)}
                >
                  <UpdateForm update={editor.item} onChange={(item) => setEditor({ kind: 'update', item })} productSlugs={productSlugs} />
                </AdminFormShell>
              )}
            </section>
          ) : (
            <>
              <div className="admin__tabs" role="tablist" aria-label="Content sections">
                {TABS.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    role="tab"
                    aria-selected={tab === t.id}
                    className={`admin__tab${tab === t.id ? ' is-active' : ''}`}
                    onClick={() => setTab(t.id)}
                  >
                    {t.label}
                  </button>
                ))}
              </div>

              {tab === 'products' && (
                <section aria-label="Products">
                  <div className="admin__list-head">
                    <h1 className="admin__title">Products</h1>
                    <button
                      type="button"
                      className="btn btn--small btn--primary"
                      onClick={() => setEditor({ kind: 'product', item: newProduct() })}
                    >
                      <IconPlus size={15} /> Add product
                    </button>
                  </div>
                  <ul className="admin__list">
                    {content.products.map((p) => (
                      <li key={p.id} className="admin__row">
                        <div>
                          <p className="admin__row-title">
                            {p.name || <em>Untitled</em>}{' '}
                            {!p.published && <span className="admin__hidden-tag">hidden</span>}
                          </p>
                          <p className="admin__row-sub">
                            <StatusBadge status={p.status} /> · /products/{p.slug || '…'} ·{' '}
                            {p.category} · {p.platform}
                          </p>
                        </div>
                        <div className="admin__row-actions">
                          <button
                            type="button"
                            className="icon-btn"
                            aria-label={`Edit ${p.name}`}
                            onClick={() => setEditor({ kind: 'product', item: { ...p } })}
                          >
                            <IconPencil size={17} />
                          </button>
                          <button
                            type="button"
                            className="icon-btn icon-btn--danger"
                            aria-label={`Delete ${p.name}`}
                            onClick={() => deleteProduct(p)}
                          >
                            <IconTrash size={17} />
                          </button>
                        </div>
                      </li>
                    ))}
                    {content.products.length === 0 && (
                      <li className="admin__empty">No products yet.</li>
                    )}
                  </ul>
                </section>
              )}

              {tab === 'projects' && (
                <section aria-label="Projects">
                  <div className="admin__list-head">
                    <h1 className="admin__title">Projects</h1>
                    <button
                      type="button"
                      className="btn btn--small btn--primary"
                      onClick={() => setEditor({ kind: 'project', item: newProject() })}
                    >
                      <IconPlus size={15} /> Add project
                    </button>
                  </div>
                  <ul className="admin__list">
                    {content.projects.map((p) => (
                      <li key={p.id} className="admin__row">
                        <div>
                          <p className="admin__row-title">
                            {p.name || <em>Untitled</em>}{' '}
                            {!p.published && <span className="admin__hidden-tag">hidden</span>}
                          </p>
                          <p className="admin__row-sub">
                            <StatusBadge status={p.status} /> · {p.category}
                          </p>
                        </div>
                        <div className="admin__row-actions">
                          <button
                            type="button"
                            className="icon-btn"
                            aria-label={`Edit ${p.name}`}
                            onClick={() => setEditor({ kind: 'project', item: { ...p } })}
                          >
                            <IconPencil size={17} />
                          </button>
                          <button
                            type="button"
                            className="icon-btn icon-btn--danger"
                            aria-label={`Delete ${p.name}`}
                            onClick={() => deleteProject(p)}
                          >
                            <IconTrash size={17} />
                          </button>
                        </div>
                      </li>
                    ))}
                    {content.projects.length === 0 && (
                      <li className="admin__empty">No projects yet.</li>
                    )}
                  </ul>
                </section>
              )}

              {tab === 'updates' && (
                <section aria-label="Updates">
                  <div className="admin__list-head">
                    <h1 className="admin__title">Updates</h1>
                    <button
                      type="button"
                      className="btn btn--small btn--primary"
                      onClick={() => setEditor({ kind: 'update', item: newUpdate() })}
                    >
                      <IconPlus size={15} /> New update
                    </button>
                  </div>
                  <ul className="admin__list">
                    {content.updates.map((u) => (
                      <li key={u.id} className="admin__row">
                        <div>
                          <p className="admin__row-title">
                            {u.title || <em>Untitled</em>}{' '}
                            {!u.published && <span className="admin__hidden-tag">hidden</span>}
                          </p>
                          <p className="admin__row-sub">
                            {u.date} · {u.tags.join(', ') || 'no tags'}
                          </p>
                        </div>
                        <div className="admin__row-actions">
                          <button
                            type="button"
                            className="icon-btn"
                            aria-label={`Edit ${u.title}`}
                            onClick={() => setEditor({ kind: 'update', item: { ...u } })}
                          >
                            <IconPencil size={17} />
                          </button>
                          <button
                            type="button"
                            className="icon-btn icon-btn--danger"
                            aria-label={`Delete ${u.title}`}
                            onClick={() => deleteUpdate(u)}
                          >
                            <IconTrash size={17} />
                          </button>
                        </div>
                      </li>
                    ))}
                    {content.updates.length === 0 && (
                      <li className="admin__empty">No updates yet.</li>
                    )}
                  </ul>
                </section>
              )}

              {tab === 'site' && (
                <section aria-label="Site information">
                  <h1 className="admin__title">Site information</h1>
                  <SiteForm site={content.site} onChange={(site) => setContent({ ...content, site })} />
                  <div className="admin__form-actions">
                    <button type="button" className="btn btn--primary" onClick={saveSite}>
                      Save site info
                    </button>
                  </div>
                </section>
              )}
            </>
          )}
        </div>
      </div>
    </>
  );
}

function AdminFormShell({
  children,
  onSave,
  onCancel,
}: {
  children: React.ReactNode;
  onSave: () => void;
  onCancel: () => void;
}) {
  return (
    <form
      className="admin__form"
      onSubmit={(e) => {
        e.preventDefault();
        onSave();
      }}
    >
      {children}
      <div className="admin__form-actions">
        <button type="submit" className="btn btn--primary">
          Save changes
        </button>
        <button type="button" className="btn btn--ghost" onClick={onCancel}>
          Cancel
        </button>
      </div>
      <p className="admin__form-note">
        Saving updates the preview in this browser only. Use{' '}
        <strong>Export JSON</strong> above to publish the changes.
      </p>
    </form>
  );
}
